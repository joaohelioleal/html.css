#include <stdio.h>

int main() {
    float x,x1,x2,x3;

    printf("Digite o valor de x1: ");
    scanf("%f", &x1);
	printf("Digite o valor de x2: ");
    scanf("%f", &x2);
	printf("Digite o valor de x3: ");
    scanf("%f", &x3);
    
    x=x1+(x2/(x3+x1))+2*(x1-x2);
    
    printf("x=%f", x);
    
    return 0;
}