#include <stdio.h>

int main() {
    float valor, total;

    printf("Digite o valor gasto no restaurante: ");
    scanf("%f", &valor);

    total = valor + (valor * 0.10);

    printf("Valor total com gorjeta: %.2f\n", total);

    return 0;
}