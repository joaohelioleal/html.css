#include <stdio.h>

int main() {
    int numero;

    printf("Digite um numero inteiro: ");
    scanf("%d", &numero);

    (numero % 3 == 0) ? printf("Eh divisivel por 3.\n") : printf("Nao eh divisivel por 3.\n");

    return 0;
}