#include <stdio.h>

int main() {
    int hora, minuto, segundos;

    printf("Digite a hora: ");
    scanf("%d", &hora);

    printf("Digite os minutos: ");
    scanf("%d", &minuto);

    segundos = hora * 3600 + minuto * 60;

    printf("Se passaram %d segundos desde o inicio do dia.\n", segundos);

    return 0;
}